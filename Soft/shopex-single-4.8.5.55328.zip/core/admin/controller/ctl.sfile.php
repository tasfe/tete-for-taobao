<?php
echo 1;
